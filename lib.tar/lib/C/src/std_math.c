#ifndef _STD_MATH_H
#define _STD_MATH_H
#include "std_math.h"
#endif
