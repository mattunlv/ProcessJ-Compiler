#ifndef _IO_FILE_H
#define _IO_FILE_H
#include "io_file.h"
int io_fileOpen_TT(char* fileName, char* Mode) {
  // implementation code goes here.
}

int io_fileClose_I(int file) {
  // implementation code goes here.
}

int io_fileWrite_IT(int file, char* data) {
  // implementation code goes here.
}

int io_fileWrite_II(int file, int data) {
  // implementation code goes here.
}

int io_fileWrite_IF(int file, float data) {
  // implementation code goes here.
}

int io_fileWrite_IJ(int file, long data) {
  // implementation code goes here.
}

int io_fileWrite_ID(int file, double data) {
  // implementation code goes here.
}

int io_fileWrite_IS(int file, short data) {
  // implementation code goes here.
}

#endif
