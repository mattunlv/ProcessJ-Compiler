#ifndef _LIB_STD_MATH_
#define _LIB_STD_MATH_
#include <math.h>
#endif

