package std;

public class strings {
   public static int string2int(String str) {
       return java.lang.Integer.parseInt(str);
   }
}
