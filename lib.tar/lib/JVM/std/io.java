package std;

public class io {
       public static void println(String s) { System.out.println(s); }
    public static void println(int s) { System.out.println(s); }
    public static void println(float s) { System.out.println(s); }
    public static void println(char s) { System.out.println(s); }
    public static void println(byte s) { System.out.println(s); }
    public static void println(short s) { System.out.println(s); }
    public static void println(long s) { System.out.println(s); }
    public static void println(double s) { System.out.println(s); }
}